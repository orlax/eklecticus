var proyectos = [
 
    {
        "Nombre": "Pal Centro",
        "subtitulo":"Compra en el centro sin salir de casa",
        "Descripcion":"un proyecto simple", 
        "thumbnail": "img/thumb_palcentro.jpg",
        "image":"http://placehold.it/1280x720"
    },
    {
        "Nombre": "Prizeeker",
        "subtitulo":"Gana por mantenerte informado",
        "Descripcion":"un proyecto simple", 
        "thumbnail": "img/thumb_prizeeker.jpg",
        "image":"http://placehold.it/1280x720"
    },
    {
        "Nombre": "Raspando y ganando",
        "subtitulo":"un sistema de sorteos digitales",
        "Descripcion":"un proyecto simple", 
        "thumbnail": "img/thumb_ryg.jpg",
        "image":"http://placehold.it/1280x720"
    },
    {
        "Nombre": "sorteando y ganando",
        "subtitulo":"una comunidad donde todos ganan",
        "Descripcion":"un proyecto simple", 
        "thumbnail": "img/thumb_sorteando.jpg",
        "image":"http://placehold.it/1280x720"
    },
    {
        "Nombre": "Ubicasat",
        "subtitulo":"una plataforma de rastreo y geolocalización",
        "Descripcion":"un proyecto simple", 
        "thumbnail": "img/thumb_ubicasat.jpg",
        "image":"http://placehold.it/1280x720"
    }  
 ];